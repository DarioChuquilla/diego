# Lumen-bootstrap-rails

A rails Lumen Bootstrap 3 Theme from bootswatch

## Installation

Add this line to your application's Gemfile:

```ruby
gem 'Lumen-bootstrap-rails'
```

And then execute:

    $ bundle

Or install it yourself as:

$ gem install Lumen-bootstrap-rails

## Usage

Add this line to your `application.js` file:
```css
//= require Lumen-bootstrap-rails
```

Add this line to your 'application.css' file:
```css
*= require Lumen-bootstrap-rails
```

## Contributing

1. Fork it
2. Create your feature branch (`git checkout -b my-new-feature`)
3. Commit your changes (`git commit -am 'Add some feature'`)
4. Push to the branch (`git push origin my-new-feature`)
5. Create new Pull Request
