module Lumenbootstraprails
  module Rails
    VERSION = '0.0.1'
  end
end