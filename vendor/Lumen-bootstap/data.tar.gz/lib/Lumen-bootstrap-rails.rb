require "Lumen-bootstrap-rails/version"

module Lumenbootstraprails
  module Rails
    if ::Rails.version < "3.1"
      require "Lumen-bootstrap-rails/railtie"
    else
      require "Lumen-bootstrap-rails/engine"
    end
  end
end
